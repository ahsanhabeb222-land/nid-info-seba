NID INFO SEBA — Starter Demo

এই ফোল্ডারে index.html আছে। এটি একটি static frontend demo; login, balance, recharge, order tracking এখনো demo-only।
কোনো NID নম্বর, জন্ম নিবন্ধন নম্বর, পাসপোর্ট নম্বর, OTP বা সংবেদনশীল ব্যক্তিগত তথ্য এই ডেমোতে সংগ্রহ করবেন না।

Android দিয়ে প্রকাশ:
1. GitHub অ্যাপে বা Chrome-এ github.com খুলে অ্যাকাউন্ট তৈরি/লগইন করুন।
2. New repository চাপুন; নাম দিন nid-info-seba; Public নির্বাচন করে Create repository করুন।
3. Add file > Upload files নির্বাচন করে index.html আপলোড করুন এবং Commit changes চাপুন।
4. Repository Settings > Pages > Build and deployment-এ Deploy from a branch নির্বাচন করুন।
5. Branch: main এবং folder: / (root) নির্বাচন করে Save চাপুন।
6. কিছুক্ষণ পর https://YOUR-USERNAME.github.io/nid-info-seba/ ঠিকানায় সাইট দেখা যাবে।

পরবর্তী ধাপ:
- নিরাপদ authentication ও database-এর জন্য Supabase-এর মতো backend সংযোগ করতে হবে।
- পেমেন্টের জন্য অনুমোদিত payment gateway merchant account প্রয়োজন।
- সরকারি NID/জন্ম নিবন্ধন/পাসপোর্ট সেবা কেবল সরকারি অনুমোদিত API ও বৈধ প্রক্রিয়ায় অফার করতে হবে।
